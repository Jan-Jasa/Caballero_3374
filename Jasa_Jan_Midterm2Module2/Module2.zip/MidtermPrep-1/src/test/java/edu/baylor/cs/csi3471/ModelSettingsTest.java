package edu.baylor.cs.csi3471;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import java.io.*;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class ModelSettingsTest {
    @DisplayName("A")
    @Test
    public void a(){

    }

    @DisplayName("B")
    @Test
    public void b(){

    }

    @DisplayName("C")
    @Test
    public void c(){

    }
}