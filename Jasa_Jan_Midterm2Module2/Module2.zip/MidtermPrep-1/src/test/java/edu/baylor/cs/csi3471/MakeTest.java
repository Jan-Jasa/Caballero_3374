package edu.baylor.cs.csi3471;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import java.io.*;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;


public class MakeTest {

    private ArrayList<Make> makes;
    private static final String FILE_NAME = "vehiclesMini.csv";
    //https://stackoverflow.com/questions/1119385/junit-test-for-system-out-println
    //info on how to sys.out with junit basically
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private PrintStream filePrintStream;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        try {
            File outputFile = new File("output.txt");
            filePrintStream = new PrintStream(new FileOutputStream(outputFile));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @BeforeEach
    public void setUp() throws FileNotFoundException {
        ModelSettings.idCounter = 0;
        Make.idCounter = 0;
        makes = Tester.loadCSV(FILE_NAME);
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        if (filePrintStream != null) {
            filePrintStream.close();
        }
    }

    @DisplayName("Should equal")
    @Test
    public void testEquals() {
        Make testMake = makes.get(0);
        assertSame(makes.get(0), testMake);
    }

    @DisplayName("PrintFilter: Make")
    @Test
    public void testPrintFilterMake() {
        for (Make out : makes)
        {
            out.printFilter("make", "VPG");
        }

        String printedData = outContent.toString().trim();

        String validData = "makeName= VPG, ID= 61, modelSettings: [\n" +
                "[mpg = [11/13/16], cylinders = 8, displacement = 4.6, fuelType = CNG, model = MV-1 CNG, transmission = Automatic 4-spd, vClass = Special Purpose Vehicle 2WD, year = 2011, ID = 12834], \n" +
                "[mpg = [13/15/18], cylinders = 8, displacement = 4.6, fuelType = Regular, model = MV-1, transmission = Automatic 4-spd, vClass = Special Purpose Vehicle 2WD, year = 2011, ID = 12835], \n" +
                "[mpg = [11/13/16], cylinders = 8, displacement = 4.6, fuelType = CNG, model = MV-1 CNG, transmission = Automatic 4-spd, vClass = Special Purpose Vehicle 2WD, year = 2012, ID = 13947], \n" +
                "[mpg = [13/15/18], cylinders = 8, displacement = 4.6, fuelType = Regular, model = MV-1, transmission = Automatic 4-spd, vClass = Special Purpose Vehicle 2WD, year = 2012, ID = 13948], \n" +
                "[mpg = [13/15/18], cylinders = 8, displacement = 4.6, fuelType = Regular, model = MV-1, transmission = Automatic 4-spd, vClass = Special Purpose Vehicle 2WD, year = 2013, ID = 15152]]";

        assertEquals(validData, printedData);

    }

    @DisplayName("PrintFilter: Model")
    @Test
    public void testPrintFilterModel() {
        for (Make out : makes)
        {
            out.printFilter("model", "Shelby");
        }

        String printedData = outContent.toString().trim();

        String expectedData = "makeName = Ford, modelSettings: \r\n" +
                "Shelby GT350 Mustang (2016)\r\n" +
                "Shelby GT350 Mustang (2017)\r\n" +
                "Shelby GT350 Mustang (2018)\r\n" +
                "Shelby GT350 Mustang (2019)";

        assertEquals(expectedData, printedData);
    }

    @DisplayName("G")
    @Test
    public void what(){

    }

}