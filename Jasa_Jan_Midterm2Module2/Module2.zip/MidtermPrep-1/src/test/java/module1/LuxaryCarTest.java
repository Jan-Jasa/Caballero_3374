package module1;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.provider.Arguments;

import java.io.*;
import java.util.ArrayList;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class LuxaryCarTest {
    private static final String FILE_NAME = "cars.csv";
    //https://stackoverflow.com/questions/1119385/junit-test-for-system-out-println
    //info on how to sys.out with junit basically
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private PrintStream filePrintStream;

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        try {
            File outputFile = new File("output.txt");
            filePrintStream = new PrintStream(new FileOutputStream(outputFile));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @BeforeEach
    public void setUp(){

    }

    private static Stream<Arguments> sumProvider() {
        return Stream.of(
                Arguments.of(1, 1, 2),
                Arguments.of(2, 3, 5)
        );
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        if (filePrintStream != null) {
            filePrintStream.close();
        }
    }

    @Test
    public void testBadConstructor(){
        Engine e = new Engine(10, "v2.0", "LuxuryCarEngine");
        assertThrows(RuntimeException.class, ()-> {
            LuxuryCar testCar = new LuxuryCar(e, "BMW", "3", "2003", "v3.0", "LuxuryCar");
        });
    }

    @Test
    public void testGoodConstructor(){
        Engine e = new Engine(40, "v2.0", "LuxuryCarEngine");
        LuxuryCar testCar = new LuxuryCar(e, "BMW", "3", "2003", "v1.0", "LuxuryCar");
    }

    @Test
    public void testWrongEngineType(){
        Engine e = new Engine(20, "v2.0", "RegularCarEngine");
        assertThrows(IllegalArgumentException.class, () -> {
            LuxuryCar testCar = new LuxuryCar(e, "Mazda", "3", "2003", "v1.0", "RegularCarEngine");
        });
    }

    @Test
    public void testMove(){
        String expectedOutput = "Power value: 40 || Engine type: LuxuryCarEngine";

        Engine e = new Engine(40, "v2.0", "LuxuryCarEngine");
        LuxuryCar testCar = new LuxuryCar(e, "BMW", "3", "2003", "v1.0", "LuxuryCar");
        testCar.move();
        String systemOutput = outContent.toString().trim();

        assertEquals(expectedOutput, systemOutput);
    }

    @Test
    public void testTakeEngine(){
        Engine e = new Engine(40, "v2.0", "LuxuryCarEngine");
        LuxuryCar testCar = new LuxuryCar(e, "BMW", "3", "2003", "v1.0", "LuxuryCar");

        Engine e2 = new Engine(50, "v2.0", "LuxuryCarEngine");
        LuxuryCar testCar2 = new LuxuryCar(e, "BMW", "3", "2003", "v1.0", "LuxuryCar");
        testCar.takeEngine(testCar2);
    }

    @Test
    public void testTakeEngineFAIL(){
        Engine e = new Engine(40, "v2.0", "LuxuryCarEngine");
        LuxuryCar testCar = new LuxuryCar(e, "Mazda", "3", "2003", "v1.0", "LuxuryCar");

        Engine e2 = new Engine(40, "v0.0", "LuxuryCarEngine");
        LuxuryCar testCar2 = new LuxuryCar(e2, "Mazda", "3", "2003", "v5.0", "LuxuryCar");
        assertThrows(RuntimeException.class, () -> {
            testCar.takeEngine(testCar2);
        });
    }
}
