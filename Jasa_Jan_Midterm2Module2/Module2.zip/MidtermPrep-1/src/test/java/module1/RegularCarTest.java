package module1;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.provider.Arguments;

import java.io.*;
import java.util.ArrayList;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class RegularCarTest {
    private static final String FILE_NAME = "cars.csv";
    //https://stackoverflow.com/questions/1119385/junit-test-for-system-out-println
    //info on how to sys.out with junit basically
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private PrintStream filePrintStream;

    public static ArrayList<Car> loadCSV(String file) throws FileNotFoundException {
        ArrayList<Car> carList = new ArrayList<>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(new File(file)));
            String line = null;

            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] split = line.split(",");
                Engine e = new Engine(Integer.parseInt(split[6]), split[7], split[5]);
                carList.add(new Car(e, split[1], split[2], split[3], split[4], split[0]));
            }
            return carList;
        } catch (IOException e) {
            String hint = "";
            try {
                hint = "Current dir is: " + new File(".").getCanonicalPath();
            } catch (Exception local) {
                hint = local.getLocalizedMessage();
            }
            throw new FileNotFoundException(e.getLocalizedMessage() + "\n" + hint);

        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.err.println(e.getLocalizedMessage());
                }
            }
        }
    }

    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        try {
            File outputFile = new File("output.txt");
            filePrintStream = new PrintStream(new FileOutputStream(outputFile));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    ArrayList<Car> carList;
//    @BeforeEach
//    public void setUp() throws FileNotFoundException {
//        carList = new ArrayList<>();
//        carList = this.loadCSV(FILE_NAME);
//    }

    @BeforeEach
    public void setUp(){

    }

    private static Stream<Arguments> sumProvider() {
        return Stream.of(
                Arguments.of(1, 1, 2),
                Arguments.of(2, 3, 5)
        );
    }

    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        if (filePrintStream != null) {
            filePrintStream.close();
        }
    }

    @Test
    public void testBadConstructor(){
        Engine e = new Engine(10, "v2.0", "RegularCarEngine");
        assertThrows(RuntimeException.class, ()-> {
            Car testCar = new Car(e, "Mazda", "3", "2003", "v3.0", "RegularCar");
        });
    }

    @Test
    public void testGoodConstructor(){
        Engine e = new Engine(10, "v2.0", "RegularCar");
        RegularCar testCar = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");
    }

    @Test
    public void testWrongEngineType(){
        Engine e = new Engine(40, "v2.0", "LuxuryCarEngine");
        assertThrows(IllegalArgumentException.class, () -> {
            RegularCar testCar = new RegularCar(e, "BMW", "3", "2003", "v1.0", "LuxuryCar");
        });
    }

    @Test
    public void testMove(){
        String expectedOutput = "Power value: 10 || Engine type: RegularCarEngine";

        Engine e = new Engine(10, "v2.0", "RegularCarEngine");
        RegularCar testCar = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");
        testCar.move();
        String systemOutput = outContent.toString().trim();

        assertEquals(expectedOutput, systemOutput);
    }

    @Test
    public void testTakeEngine(){
        Engine e = new Engine(10, "v2.0", "RegularCarEngine");
        RegularCar testCar = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");

        Engine e2 = new Engine(10, "v2.0", "RegularCarEngine");
        RegularCar testCar2 = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");
        testCar.takeEngine(testCar2);
    }

    @Test
    public void testTakeEngineFAIL(){
        Engine e = new Engine(10, "v2.0", "RegularCarEngine");
        RegularCar testCar = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");

        Engine e2 = new Engine(10, "v0.0", "RegularCarEngine");
        RegularCar testCar2 = new RegularCar(e2, "Mazda", "3", "2003", "v5.0", "RegularCar");
        assertThrows(RuntimeException.class, () -> {
            testCar.takeEngine(testCar2);
        });
    }
}
