package module2;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.event.*;
import java.io.*;
import java.lang.*;
import java.awt.*;
import java.util.ArrayList;

public class MyDialog extends JDialog{
    private JTable table;

    public MyDialog(JTable owner){
        super(javax.swing.SwingUtilities.windowForComponent(owner));
        table = owner;
        createGUI();
    }

    private void createGUI(){
        setPreferredSize(new Dimension(600, 400));
        setTitle(getClass().getSimpleName());
        JPanel listPane = new JPanel();

        listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
        //JLabel label = new JLabel("Hello:");
        //label.setAlignmentX(Component.CENTER_ALIGNMENT);
        //listPane.add(label);

        int row = table.getSelectedRowCount();
        int rowSelected = table.getSelectedRow();
        Boolean multiRowSelected = false;
        Boolean oneRowSelected = false;
        JLabel dataLabel = null;
        JLabel instructionLabel = null;
        if(row > 1){
            dataLabel = new JLabel("Cannot duplicate multiple rows");
            multiRowSelected = true;
        }
        else if(row == 0){
            dataLabel = new JLabel("No row selected.");
            instructionLabel = new JLabel("No row selected; provide inputs to all fields and press [Add Row] button.");
            listPane.add(instructionLabel);
        }
        else if(row == 1){
            oneRowSelected = true;
            dataLabel = new JLabel(table.getModel().getValueAt(rowSelected,1)+" "+table.getModel().getValueAt(rowSelected,2));
            instructionLabel = new JLabel("You selected this row as initial inputs. Please revise them as needed and press [Add Row] button.");
            listPane.add(instructionLabel);
        }
        dataLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        listPane.add(dataLabel);

        JPanel fieldPanel0 = new JPanel();
        JPanel fieldPanel1 = new JPanel();
        JPanel fieldPanel2 = new JPanel();
        JPanel fieldPanel3 = new JPanel();
        JPanel fieldPanel4 = new JPanel();
        JPanel fieldPanel5 = new JPanel();
        JPanel fieldPanel6 = new JPanel();
        JPanel fieldPanel7 = new JPanel();

        String[] carTypes = {"RegularCar","LuxuryCar"};
        JComboBox<String> comboBox0 = new JComboBox<>(carTypes);
        String[] engineVersions = {"v0.0", "v2.0", "v3.0","v4.0","v5.0"};
        JComboBox<String> comboBox4 = new JComboBox<>(engineVersions);
        JComboBox<String> comboBox7 = new JComboBox<>(engineVersions);
        String[] engineTypes = {"RegularCarEngine","LuxuryCarEngine"};
        JComboBox<String> comboBox5 = new JComboBox<>(engineTypes);
        JTextField textField1 = new JTextField(20);
        JTextField textField2 = new JTextField(20);
        JTextField textField3 = new JTextField(20);
        JTextField textField6 = new JTextField(20);
        if(multiRowSelected == false){
            ////PART 2
            String[] columnNames = {"Car Type",
                    "Make",
                    "Model",
                    "Year",
                    "Minimum Version",
                    "Engine Type",
                    "Power",
                    "Engine Version"};

            Integer indexer = 0;
            for (String heading : columnNames) {
                // Create a panel for each field
                JPanel fieldPanel = new JPanel();
                fieldPanel.setLayout(new BorderLayout());

                // Create a label for the heading
                JLabel label = new JLabel(heading + ": ");

                // Create a text field for the entry
                if(indexer == 0){
                    if(oneRowSelected == true) {
                        comboBox0.setSelectedItem(table.getModel().getValueAt(rowSelected, indexer).toString());
                    }
                    fieldPanel0.add(label, BorderLayout.WEST);
                    fieldPanel0.add(comboBox0, BorderLayout.CENTER);
                    listPane.add(fieldPanel0);
                }
                else if(indexer == 5){
                    if(oneRowSelected == true) {
                        comboBox5.setSelectedItem(table.getModel().getValueAt(rowSelected, indexer).toString());
                    }
                    fieldPanel5.add(label, BorderLayout.WEST);
                    fieldPanel5.add(comboBox5, BorderLayout.CENTER);
                    listPane.add(fieldPanel5);
                }
                else if(indexer == 4){
                    if(oneRowSelected == true) {
                        comboBox4.setSelectedItem(table.getModel().getValueAt(rowSelected, indexer).toString());
                    }
                    fieldPanel4.add(label, BorderLayout.WEST);
                    fieldPanel4.add(comboBox4, BorderLayout.CENTER);
                    listPane.add(fieldPanel4);
                }
                else if(indexer == 7){
                    if(oneRowSelected == true) {
                        comboBox7.setSelectedItem(table.getModel().getValueAt(rowSelected, indexer).toString());
                    }
                    fieldPanel7.add(label, BorderLayout.WEST);
                    fieldPanel7.add(comboBox7, BorderLayout.CENTER);
                    listPane.add(fieldPanel7);
                }
                else{
                    if(oneRowSelected == true){
                        if (indexer==1){
                            textField1.setText(table.getModel().getValueAt(rowSelected,indexer).toString());
                        } else if (indexer==2) {
                            textField2.setText(table.getModel().getValueAt(rowSelected,indexer).toString());
                        } else if (indexer==3) {
                            textField3.setText(table.getModel().getValueAt(rowSelected,indexer).toString());
                        } else if (indexer==6) {
                            textField6.setText(table.getModel().getValueAt(rowSelected,indexer).toString());
                        }
                    }
                    if(indexer==1){
                        fieldPanel1.add(label, BorderLayout.WEST);
                        fieldPanel1.add(textField1, BorderLayout.CENTER);
                        listPane.add(fieldPanel1);
                    } else if (indexer==2) {
                        fieldPanel2.add(label, BorderLayout.WEST);
                        fieldPanel2.add(textField2, BorderLayout.CENTER);
                        listPane.add(fieldPanel2);
                    } else if (indexer == 3) {
                        fieldPanel3.add(label, BorderLayout.WEST);
                        fieldPanel3.add(textField3, BorderLayout.CENTER);
                        listPane.add(fieldPanel3);
                    } else if (indexer==6) {
                        fieldPanel6.add(label, BorderLayout.WEST);
                        fieldPanel6.add(textField6, BorderLayout.CENTER);
                        listPane.add(fieldPanel6);
                    }
                }
                indexer++;
            }
            ////
            JButton addButton = new JButton("Add new row");
            addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String item0 = comboBox0.getSelectedItem().toString();
                    String item1 = textField1.getText().toString();
                    String item2 = textField2.getText().toString();
                    String item3 = textField3.getText().toString();
                    String item4 = comboBox4.getSelectedItem().toString();
                    String item5 = comboBox5.getSelectedItem().toString();
                    String item6 = textField6.getText().toString();
                    String item7 = comboBox7.getSelectedItem().toString();
                    System.out.println(item0 + item1 + item2 +
                            item3 + item4 + item5 + item6 + item7);

                    ((DefaultTableModel)table.getModel()).addRow(new Object[]{item0, item1, item2,
                            Integer.parseInt(item3), item4, item5, Integer.parseInt(item6), item7});
                    dispose();
                    JOptionPane.showMessageDialog(table, "Added new record");

                    //LAST PART, GO ADD TO CSV LOSAH
                    String[] itemLoaderArray = {item0, item1, item2, item3, item4, item5, item6, item7};

                    try (FileWriter fw = new FileWriter("src/main/resources/cars.csv", true);
                         BufferedWriter bw = new BufferedWriter(fw);
                         PrintWriter out = new PrintWriter(bw)) {
                        String line = String.join(",", itemLoaderArray); // Join all details separated by commas
                        String outputLine = (line);
                        out.println(outputLine);
                    } catch (IOException eess) {
                    }
                }
            });

            listPane.add(addButton);
        }

        add(listPane);
        pack();
        setLocationRelativeTo(getParent());
        setVisible(true);
    }

    @Override
    public void dispose(){
        super.dispose();
    }
}
