package module1;

public class Car {
    private String Make;
    private String Model;
    private String Year;
    private String minimumVersion;
    private Engine engine;

    public String getCarType() {
        return carType;
    }

    private String carType;

    public String getMake() {return Make;}

    public void setMake(String make) {Make = make;}

    public String getModel() {return Model;}

    public void setModel(String model) {Model = model;}

    public String getYear() {return Year;}

    public void setYear(String year) {Year = year;}

    public String getMinimumVersion() {return minimumVersion;}

    public void setMinimumVersion(String minimumVersion) {this.minimumVersion = minimumVersion;}

    public Engine getEngine() {return engine;}

    public void setEngine(Engine engine) {this.engine = engine;}

    //move method
    public void move(){
        String output = this.engine.power();
        System.out.println(output);
    }

    //constructor
    public Car(Engine e, String make, String model, String year, String minVers, String type){
        try{
            //1 = higher
            //0 = same
            //-1 = lower
            if(e.getVersion().compareToIgnoreCase(minVers) == -1){
                //if engine is lower than minimum
                throw new IllegalArgumentException("Engine version too low.");
            }
            else{
                this.setEngine(e);
                this.setYear(year);
                this.setMake(make);
                this.setModel(model);
                this.setMinimumVersion(minVers);
                this.carType = type;
            }
        } catch(IllegalArgumentException es){
            throw new RuntimeException(es);
        }
    }

    public void takeEngine(Car c){
        try{
            if(c.getEngine().getVersion().compareToIgnoreCase(this.getMinimumVersion()) == -1){
                throw new IllegalArgumentException("Engine version too low.");
            }
            else{

            }
        }catch(IllegalArgumentException es){
            throw new RuntimeException(es);
        }
    }
}
