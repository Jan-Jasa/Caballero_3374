package module1;

public class RegularCar extends Car {
    public RegularCar(Engine e, String make, String model, String year, String minVers, String type) {
        super(e, make, model, year, minVers, type);
        if(e.getPower() > 30){
            throw new IllegalArgumentException("Luxury Engine used.");
        }
    }
}
