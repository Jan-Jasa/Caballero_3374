package module1;

public class LuxuryCar extends Car{
    public LuxuryCar(Engine e, String make, String model, String year, String minVers, String type) {
        super(e, make, model, year, minVers, type);
        if(e.getPower() < 30){
            throw new IllegalArgumentException("Regular Engine used.");
        }
    }
}
