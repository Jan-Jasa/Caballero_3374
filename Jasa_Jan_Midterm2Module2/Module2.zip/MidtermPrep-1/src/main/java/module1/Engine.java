package module1;

public class Engine {
    //POWER 10 - 30 = REGULAR CAR
    //POWER 31 - 50 = LUXURY
    private Integer Power; //ranges 10-50
    private String version; //v1.0 - v5.0
    private String type;

    public Integer getPower() {
        return Power;
    }

    public String getVersion() {
        return version;
    }

    public String power(){
        String output = "Power value: " + this.getPower() + " || Engine type: " + this.type;
        return output;
    }

    public Engine(Integer p, String v, String t){
        this.Power = p;
        this.version = v;
        this.type = t;
    }
}
