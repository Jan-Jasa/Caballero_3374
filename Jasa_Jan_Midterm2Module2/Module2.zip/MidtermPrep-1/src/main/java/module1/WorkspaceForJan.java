package module1;

public class WorkspaceForJan {
    public static void main(String[] args){
        String s = "asdEngine";
        s.substring(0, 3);
        System.out.println(s.substring(0,3));

        Engine e = new Engine(10, "v2.0", "RegularCar");
        RegularCar testCar = new RegularCar(e, "Mazda", "3", "2003", "v1.0", "RegularCar");
    }
}
