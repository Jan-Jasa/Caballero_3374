/*
 * Author: Jan Jasa
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: ModelSettings.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

public class ModelSettings {

	public static class MPG {
		Integer city;
		Integer avg;
		Integer hwy;

		//SETTERS
		public void setCityMPG(Integer mpg){this.city = mpg;}
		public void setAvgMPG(Integer mpg){this.avg = mpg;}
		public void setHwyMPG(Integer mpg){this.hwy = mpg;}

		//GETTERS
		public Integer getCityMPG(){return this.city;}
		public Integer getAvgMPG(){return this.avg;}
		public Integer getHwyMPG(){return this.hwy;}

		//CONSTRUCTORS
		public MPG(){
			this.city = 0;
			this.avg = 0;
			this.hwy = 0;
		}
		public MPG(String[] line){
			int c = Integer.parseInt(line[0]);
			int a = Integer.parseInt(line[1]);
			int h = Integer.parseInt(line[5]);

			this.city = c;
			this.avg = a;
			this.hwy = h;
		}

		public String getOverallAverage(){
			String cString = String.valueOf(this.city);
			String aString = String.valueOf(this.avg);
			String hString = String.valueOf(this.hwy);

			Double cDouble = Double.parseDouble(cString);
			Double aDouble = Double.parseDouble(aString);
			Double hDouble = Double.parseDouble(hString);

			String result = String.valueOf((cDouble+aDouble+hDouble)/3);
			return result;
		}

		@Override
		public String toString() {
			String output = ("[" + getCityMPG() + "/" + getAvgMPG() + "/" + getHwyMPG() + "]");

			return output;
		}

		@Override
		public boolean equals(Object object) {
			if(object == this){
				return true;
			}
			if(object == null || object.getClass() != this.getClass()){
				return false;
			}

			MPG guest = (MPG) object;
			return city.equals(guest.city)
					&& avg.equals(guest.avg)
					&& hwy.equals(guest.hwy);
		}

		@Override
		public int hashCode()
		{
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ city;
			result = prime * result
					+ hwy;
			result = prime * result
					+ avg;
			return result;
		}
	}

	//VARIABLES
	private MPG mpg = null;
	private String fuelType, model, transmission, vClass
			,cylinders, year, volume= null;
	private Integer id = null;
	public static int idCounter = 0;

	//LINKS MAKE AND MODEL SETTING
	private Make make;

	//SETTERS
	public void setMpg(MPG mpg) {this.mpg = mpg;}
	public void setMake(Make make){this.make = make;}
	//GETTERS
	public MPG getMpg() {return mpg;}
	public String getModel(){return this.model;}
	public String getFuelType(){return this.fuelType;}
	public String getTransmission(){return this.transmission;}
	public String getVClass(){return this.vClass;}
	public String getCylinders(){return this.cylinders;}
	public String getYear(){return this.year;}
	public String getVolume(){return this.volume;}
	public Make getMake(){return this.make;}

	//COMPARE
	public int compareTo(ModelSettings modelsetting){
		/*Equal == 0
		* Lesser == -1
		* Greater == 1*/
		int result = year.compareTo(modelsetting.year);
		if(result == 0){
			result = transmission.compareTo(modelsetting.transmission);
			if(result == 0){
				result = volume.compareTo(modelsetting.volume);
			}
		}
		return result;
	}


	public ModelSettings(String[] line) {
		this.cylinders = line[2];
		this.volume = line[3];
		this.fuelType = line[4];
		this.model = line[7];
		this.transmission = line[8];
		this.vClass = line[9];
		this.year = line[10];
		this.mpg = new MPG(line);
		this.id = idCounter;
		idCounter++;
	}

	@Override
	public boolean equals(Object object) {
		if(object == this){
			return true;
		}
		if(object == null || object.getClass() != this.getClass()){
			return false;
		}

		ModelSettings guest = (ModelSettings) object;
		return getModel().equals(guest.getModel())
				&& getCylinders().equals(guest.getCylinders())
				&& getFuelType().equals(guest.getFuelType())
				&& getTransmission().equals(guest.getTransmission())
				&& getVClass().equals(guest.getVClass())
				&& getYear().equals(guest.getYear())
				&& getMpg().equals(guest.getMpg())
				&& getVolume().equals(guest.getVolume());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.model == null) ? 0 : this.model.hashCode());
		result = prime * result + ((this.year == null) ? 0 : this.year.hashCode());
		result = prime * result + ((this.cylinders == null) ? 0 : this.cylinders.hashCode());
		result = prime * result + ((this.fuelType == null) ? 0 : this.fuelType.hashCode());
		result = prime * result + ((this.transmission == null) ? 0 : this.transmission.hashCode());
		result = prime * result + ((this.volume == null) ? 0 : this.volume.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "\n[" + "mpg = " + mpg.toString()
				+ ", cylinders = " + cylinders
				+ ", displacement = " + volume
				+ ", fuelType = " + fuelType
				+ ", model = " + model
				+ ", transmission = " + transmission
				+ ", vClass = " + vClass
				+ ", year = " + year
				+ ", ID = " + id
				+ "]";

	}
}
