/*
 * Author: Jan Jasa
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: Tester.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Tester {
	//SORTERS
	static class alphabeticalSort implements Comparator<Make> {
		@Override
		public int compare(Make a, Make b) {
			return (a.getMakeName().compareToIgnoreCase(b.getMakeName()));
		}
	}

	static class reverseAlphabeticalSort implements Comparator<Make>{
		@Override
		public int compare(Make a, Make b){
			return (a.getMakeName().compareToIgnoreCase(b.getMakeName()))*-1;
		}
	}

	static class vClassSort implements Comparator<String[]>{
		@Override
		public int compare(String[] a, String[] b){
			return a[0].compareToIgnoreCase(b[0]);
		}
	}

	static class top5Sort implements Comparator<String[]>{
		@Override
		public int compare(String[] a, String[] b){
			return a[2].compareToIgnoreCase(b[2])*-1;
		}
	}

	private static final int ADDITIONALARG_2 = 3;
	private static final int ADDITIONALARG_1 = 2;
	private static final int FILE_NAME = 1;
	private static final int OPTION = 0;

	private static int readOption(String[] args) {
		Integer option = null;
		/*
		if (args.length < 2 what is the expected length) {
			System.err.println("USAGE: java Tester <filename>");
			System.exit(1);
		} else {
			try {
				option = Integer.parseInt(args[OPTION]);
			} catch (NumberFormatException e) {
				System.err.println("call as java Tester <filename>");
				System.exit(1);
			}
		}
		 */
		option = Integer.parseInt(args[OPTION]);
		return option;
	}

	public static ArrayList<Make> loadCSV(String file) throws FileNotFoundException {
		ArrayList<Make> makeList = new ArrayList<>();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(new File(file)));
			String line = null;

			//skip first two lines
			reader.readLine();
			reader.readLine();

			boolean makeExists = false;
			while ((line = reader.readLine()) != null) {
				String[] split = line.split(",");
				makeExists = false;

				if(makeList.isEmpty()){
					//first time only, to initialize
					makeList.add(new Make(split));
				}
				else{
					for(Make m : makeList){
						//make exists
						if(m.getMakeName().equals(split[6])){
							m.addModelSetting(split);
							makeExists = true;
						}
					}
					if(!makeExists){
						makeList.add(new Make(split));
					}
				}
			}
			return makeList;
		} catch (IOException e) {
			File aaa = new File(".");
			for(String fileNames : aaa.list()) System.out.println(fileNames);
			String hint = "";
			try {
				hint = "Current dir is: " + new File(".").getCanonicalPath();
			} catch (Exception local) {
				hint = local.getLocalizedMessage();
			}
			throw new FileNotFoundException(e.getLocalizedMessage() + "\n" + hint);

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					System.err.println(e.getLocalizedMessage());
				}
			}
		}
	}

	public static void main(String[] args) {
		int option = readOption(args);

		ArrayList<Make> makeList = null;

		try {
			makeList = loadCSV(args[FILE_NAME]);
		} catch (FileNotFoundException e) {
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}

		//DONE
		if (option == 1) {
			//Total number of makes in file
			System.out.println("# of makes = " + makeList.size());
			//Each make w/ number of modelSetting instances (Z->A)
			System.out.println("===============");
			makeList.sort(new reverseAlphabeticalSort());
			for (Make m : makeList){
				System.out.println("Make name = " + m.getMakeName() + " || # of model settings = " + m.getModelSettingList().size());
			}
			//toString on each Make (Z->A)
			System.out.println("===============");
			for (Make m : makeList){
				System.out.println(m);
			}
		}
		else if (option == 2) {
			String columnName = args[ADDITIONALARG_1];
			String value = args[ADDITIONALARG_2];
			makeList.sort(new alphabeticalSort());
			for(Make m : makeList){
				m.printFilter(columnName, value);
			}

		}
		else if(option == 3){
			//each vclass
			ArrayList<String[]> VClass = new ArrayList<>();
			for(Make m : makeList){
				for(ModelSettings ms : m.getModelSettingList()){
					boolean vClassInList = false;

					//check is vClass exists alrdy
					for(int i=0; i<VClass.size(); i++){
						if(VClass.get(i)[0].equals(ms.getVClass())){
							vClassInList = true;
							//add value to average and replace
							Integer tempMPG = ms.getMpg().getAvgMPG();
							Integer currentMPG = Integer.parseInt(VClass.get(i)[1]);
							Integer totalMPG = tempMPG+currentMPG;
							VClass.get(i)[1] = Integer.toString(totalMPG);

							Integer tempSize = Integer.parseInt(VClass.get(i)[2]);
							tempSize++;
							VClass.get(i)[2] = Integer.toString(tempSize);

							i = VClass.size();
						}
					}

					//if vClass doesn't exist, add to vClass array
					if(!vClassInList){
						String[] temp = new String[]{ms.getVClass(), Integer.toString(ms.getMpg().getAvgMPG()), "1"};
						VClass.add(temp);
					}
				}
			}
			VClass.sort(new vClassSort());
			for(String[] v : VClass){
				Double avg = Double.parseDouble(v[1])/Double.parseDouble(v[2]);
				System.out.println(v[0] + "'s avg= " + avg);
			}
		}
		else if(option == 4){
			makeList.sort(new alphabeticalSort());
			for(Make m : makeList){
				m.howManyCarModelsMadePerYear();
			}
		}
		else if(option == 5){
			ArrayList<String[]> top5List = new ArrayList<>();
			for(Make m : makeList){
				for(ModelSettings ms : m.getModelSettingList()){
					String[] temp = new String[]{ms.getModel(), ms.getYear(), ms.getMpg().getOverallAverage()};
					top5List.add(temp);
				}
			}
			top5List.sort(new top5Sort());
			for(int i=0; i<5; i++){
				System.out.println("Model = " + top5List.get(i)[0] + " " + top5List.get(i)[1] + " || Fuel Efficiency: " + top5List.get(i)[2]);
			}
		}
	}
}
