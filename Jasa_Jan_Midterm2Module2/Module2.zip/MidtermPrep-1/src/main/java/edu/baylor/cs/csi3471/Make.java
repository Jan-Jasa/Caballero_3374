/*
 * Author: Jan Jasa
 * Course: CSI 3471
 * Assignment: Lab 5
 * File: Make.java
 * Description: Your brief description
 */

package edu.baylor.cs.csi3471;

import java.util.*;

public class Make {
	//SORTERS
	static class sortBySettings implements Comparator<ModelSettings>{
		@Override
		public int compare(ModelSettings A, ModelSettings B){
			return A.compareTo(B);
		}
	}
	static class sortByYear implements Comparator<ModelSettings>{
		@Override
		public int compare(ModelSettings A, ModelSettings B){
			Integer year1 = Integer.parseInt(A.getYear());
			Integer year2 = Integer.parseInt(B.getYear());
			return year1.compareTo(year2);
		}
	}
	static class sortByTransmission implements Comparator<ModelSettings>{
		@Override
		public int compare(ModelSettings A, ModelSettings B){
			String transmission1 = A.getTransmission();
			String transmission2 = B.getTransmission();
			return transmission1.compareToIgnoreCase(transmission2);
		}
	}
	static class sortByMPG implements Comparator<ModelSettings>{
		@Override
		public int compare(ModelSettings A, ModelSettings B){
			return A.getMpg().avg.compareTo(B.getMpg().avg);
		}
	}

	//VARIABLES
	private ArrayList<ModelSettings> modelSettingList;
	private String makeName; //index[6]
	private Integer uniqueID;
	public static int idCounter = 0;

	//Constructor
	public Make(String[] line){
		makeName = line[6];
		ModelSettings ms = new ModelSettings(line);
		uniqueID = idCounter;
		idCounter++;

		ms.setMake(this);
		modelSettingList = new ArrayList<>();
		modelSettingList.add(ms);
	}

	public void setMakeID(int id){this.uniqueID = id;}
	public int getMakeID(){return this.uniqueID;}
	public ArrayList<ModelSettings> getModelSettingList(){return modelSettingList;}
	public String getMakeName(){return this.makeName;}

	//add a model setting to existing make (take latest duplicate found)
	public void addModelSetting(String[] line){
		ModelSettings tmp = new ModelSettings(line);
		tmp.setMake(this);

		boolean flag = false;
		for(int i = 0; i< modelSettingList.size(); i++){
			//CHECKS FOR DUPLICATE NAME, TRANMISSION, VCLASS, AND YEAR BEFORE CHANGING
			if(modelSettingList.get(i).getModel().equals(tmp.getModel())
					&& modelSettingList.get(i).getTransmission().equals(tmp.getTransmission())
					&& modelSettingList.get(i).getVClass().equals(tmp.getVClass())
					&& modelSettingList.get(i).getYear().equals(tmp.getYear())){

				modelSettingList.set(i, tmp);
				flag = true;
			}
		}

		if(!flag){
			modelSettingList.add(tmp);
		}
	}

	public void howManyCarModelsMadePerYear(){
		modelSettingList.sort(new sortByYear());
		String currentYear = modelSettingList.get(0).getYear();
		Integer numModels = 1;
		for(int i=0; i<modelSettingList.size(); i++){
			if(!currentYear.equals(modelSettingList.get(i).getYear())){
				System.out.print("\n{" + makeName + ";" + currentYear + ";" + numModels + "}");
				numModels = 1;
				currentYear = modelSettingList.get(i).getYear();
			}
			else{
				numModels++;
			}
		}
		System.out.print("\n{" + makeName + ";" + currentYear + ";" + numModels + "}");
	}


	public void printFilter(String columnName, String value){
		if(columnName.equals("make")){
			if(makeName.contains(value)){
				System.out.println(this);
			}
		}
		else if(columnName.equals("model")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getModel().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("trany")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getTransmission().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("VClass")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getVClass().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("year")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getYear().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("fuelType")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getFuelType().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("cylinders")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getCylinders().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else if(columnName.equals("displ")){
			boolean started = false;

			for(ModelSettings ms : modelSettingList){
				if(ms.getVolume().contains(value)){
					if(!started){
						System.out.println("\nmakeName = " + makeName + ", modelSettings: ");
						started = true;
					}
					System.out.println(ms.getModel() + " (" + ms.getYear() + ")");
				}
			}
		}
		else{
			System.out.println("Not a valid columnName.");
			System.out.println("Must be one of the following: make, model, trany, VClass, year, fuelType, cylinders, displ");
		}
	}

	//standard overrides
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.makeName.hashCode();
		result = prime * result + this.modelSettingList.hashCode();
		return result;
	}

	@Override
	public String toString() {
		modelSettingList.sort(new sortBySettings());
		return "\nmakeName= " + makeName + ", ID= " + uniqueID + ", modelSettings: " + modelSettingList;

	}

	@Override
	public boolean equals(Object object) {
		if(object == this){
			return true;
		}
		if(object == null || object.getClass() != this.getClass()){
			return false;
		}

		Make guest = (Make) object;
		return makeName.equals(guest.makeName)
				&& modelSettingList.equals(guest.modelSettingList)
				&& uniqueID.equals(guest.uniqueID);
	}
}
